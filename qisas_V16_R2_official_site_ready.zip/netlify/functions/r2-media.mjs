import { S3Client, PutObjectCommand, DeleteObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
const ADMIN_PIN = process.env.ADMIN_PIN;
const R2_ACCOUNT_ID = process.env.R2_ACCOUNT_ID;
const R2_ACCESS_KEY_ID = process.env.R2_ACCESS_KEY_ID;
const R2_SECRET_ACCESS_KEY = process.env.R2_SECRET_ACCESS_KEY;
const R2_BUCKET_NAME = process.env.R2_BUCKET_NAME || 'qisas-videos';
const R2_PUBLIC_BASE_URL = (process.env.R2_PUBLIC_BASE_URL || 'https://pub-025c138d90ed4d4bb9d231b4589a28bb.r2.dev').replace(/\/$/, '');

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false } });
const s3 = new S3Client({
  region: 'auto',
  endpoint: `https://${R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
  credentials: { accessKeyId: R2_ACCESS_KEY_ID, secretAccessKey: R2_SECRET_ACCESS_KEY },
});

const json = (statusCode, body) => ({ statusCode, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' }, body: JSON.stringify(body) });
const ok = (body) => json(200, { success: true, ...body });
const fail = (statusCode, error) => json(statusCode, { success: false, error });

function validConfig() {
  return SUPABASE_URL && SUPABASE_SERVICE_ROLE_KEY && ADMIN_PIN && R2_ACCOUNT_ID && R2_ACCESS_KEY_ID && R2_SECRET_ACCESS_KEY;
}
function validPin(pin) { return typeof pin === 'string' && pin === ADMIN_PIN; }
function safeExt(name, fallback) {
  const m = String(name || '').toLowerCase().match(/\.(mp4|jpe?g|png|webp)$/);
  return m ? m[0] : fallback;
}
function objectKey(kind, id, filename) {
  const ext = kind === 'video' ? safeExt(filename, '.mp4') : safeExt(filename, '.jpg');
  return `${kind === 'video' ? 'videos' : 'thumbnails'}/${id}${ext}`;
}
function rawKey(path) { return String(path || '').replace(/^r2:/, ''); }
function publicUrl(path) { const key = rawKey(path); return key ? `${R2_PUBLIC_BASE_URL}/${key.split('/').map(encodeURIComponent).join('/')}` : ''; }

async function presign(key, contentType) {
  const command = new PutObjectCommand({ Bucket: R2_BUCKET_NAME, Key: key, ContentType: contentType || 'application/octet-stream' });
  return getSignedUrl(s3, command, { expiresIn: 900 });
}

export default async (req) => {
  if (!validConfig()) return fail(500, 'R2/Supabase server configuration is incomplete.');
  let body;
  try { body = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : (req.body || {}); }
  catch { return fail(400, 'Invalid JSON.'); }

  const { action, pin } = body;
  if (!validPin(pin)) return fail(401, 'رمز الإدارة غير صحيح.');

  try {
    if (action === 'verify') return ok({});

    if (action === 'presign') {
      const { videoKey, thumbnailKey, videoType, thumbnailType } = body;
      const out = {};
      if (videoKey) out.videoUrl = await presign(videoKey, videoType || 'video/mp4');
      if (thumbnailKey) out.thumbnailUrl = await presign(thumbnailKey, thumbnailType || 'image/jpeg');
      return ok(out);
    }

    if (action === 'create') {
      const id = String(body.id || '');
      if (!id || !/^[0-9a-f-]{36}$/i.test(id)) return fail(400, 'معرّف القصة غير صالح.');
      const videoPath = body.videoKey ? `r2:${body.videoKey}` : null;
      const thumbnailPath = body.thumbnailKey ? `r2:${body.thumbnailKey}` : null;
      const row = {
        id,
        title: String(body.title || '').trim(),
        description: String(body.description || '').trim(),
        video_path: videoPath,
        thumbnail_path: thumbnailPath,
        is_short: !!body.is_short,
        related_video_id: body.related_video_id || null,
        status: 'published',
      };
      if (!row.title || !row.video_path) return fail(400, 'العنوان والفيديو مطلوبان.');
      const { error } = await supabase.from('videos').insert(row);
      if (error) return fail(500, error.message);
      return ok({ id, video_path: videoPath, thumbnail_path: thumbnailPath, video_url: publicUrl(videoPath), thumbnail_url: publicUrl(thumbnailPath) });
    }

    if (action === 'update') {
      const id = String(body.id || '');
      if (!id) return fail(400, 'معرّف القصة مفقود.');
      const { data: old, error: oldError } = await supabase.from('videos').select('id,video_path,thumbnail_path').eq('id', id).maybeSingle();
      if (oldError || !old) return fail(404, 'القصة غير موجودة.');
      const patch = {};
      if (body.title !== undefined) patch.title = String(body.title).trim();
      if (body.description !== undefined) patch.description = String(body.description).trim();
      if (body.is_short !== undefined) patch.is_short = !!body.is_short;
      if (body.related_video_id !== undefined) patch.related_video_id = body.related_video_id || null;
      if (body.videoKey) patch.video_path = `r2:${body.videoKey}`;
      if (body.thumbnailKey) patch.thumbnail_path = `r2:${body.thumbnailKey}`;
      const { error } = await supabase.from('videos').update(patch).eq('id', id);
      if (error) return fail(500, error.message);
      if (body.videoKey && old.video_path && old.video_path !== patch.video_path) await s3.send(new DeleteObjectCommand({ Bucket: R2_BUCKET_NAME, Key: rawKey(old.video_path) }));
      if (body.thumbnailKey && old.thumbnail_path && old.thumbnail_path !== patch.thumbnail_path) await s3.send(new DeleteObjectCommand({ Bucket: R2_BUCKET_NAME, Key: rawKey(old.thumbnail_path) }));
      return ok({ id, video_path: patch.video_path || old.video_path, thumbnail_path: patch.thumbnail_path || old.thumbnail_path });
    }

    if (action === 'delete') {
      const id = String(body.id || '');
      if (!id) return fail(400, 'معرّف القصة مفقود.');
      const { data: old, error: oldError } = await supabase.from('videos').select('id,video_path,thumbnail_path').eq('id', id).maybeSingle();
      if (oldError || !old) return fail(404, 'القصة غير موجودة.');
      for (const key of [old.video_path, old.thumbnail_path].filter(Boolean)) { if (String(key).startsWith('r2:')) await s3.send(new DeleteObjectCommand({ Bucket: R2_BUCKET_NAME, Key: rawKey(key) })); }
      const { error } = await supabase.from('videos').delete().eq('id', id);
      if (error) return fail(500, error.message);
      return ok({});
    }

    return fail(400, 'عملية غير معروفة.');
  } catch (e) {
    return fail(500, e?.message || 'Server error.');
  }
};
