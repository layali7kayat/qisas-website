# نقل الوسائط إلى Cloudflare R2

## ما الذي تغير؟
- لوحة الإدارة وتصميمها لم يتغيرا.
- حد الفيديو ما زال 50MB.
- العناوين والوصف والمشاهدات والتعليقات تبقى في Supabase.
- الفيديوهات والصور الجديدة ترفع مباشرة إلى R2.
- المسارات التي تبدأ بـ `r2:` تعني أن الملف أصبح في R2.
- المسارات القديمة بدون `r2:` تستمر مؤقتًا من Supabase حتى انتهاء الترحيل.

## متغيرات Netlify المطلوبة
أضف هذه المتغيرات في Netlify > Project configuration > Environment variables:

- `SUPABASE_URL` = رابط مشروع Supabase
- `SUPABASE_SERVICE_ROLE_KEY` = Service Role Key الخاص بـ Supabase (سري جدًا، لا يوضع في الواجهة)
- `ADMIN_PIN` = نفس رمز الإدارة الحالي المكوّن من 5 أرقام
- `R2_ACCOUNT_ID` = Cloudflare Account ID
- `R2_ACCESS_KEY_ID` = Access Key ID الجديد الخاص بـ R2
- `R2_SECRET_ACCESS_KEY` = Secret Access Key الجديد الخاص بـ R2
- `R2_BUCKET_NAME` = `qisas-videos`
- `R2_PUBLIC_BASE_URL` = `https://pub-025c138d90ed4d4bb9d231b4589a28bb.r2.dev`

لا ترسل أي قيمة سرية داخل المحادثة.

## بعد النشر
1. جرّب فتح لوحة الإدارة وتسجيل الدخول.
2. لا تحذف أي ملفات من Supabase Storage.
3. جرّب نشر فيديو أقل من 50MB وصورة مصغرة.
4. تأكد أن الفيديو الجديد يظهر ويعمل.
5. شغّل الترحيل القديم من جهازك بعد تثبيت الاعتمادات:

```bash
npm install
```

للمعاينة فقط دون نقل:

```bash
DRY_RUN=1 node scripts/migrate-supabase-media-to-r2.mjs
```

للنقل الفعلي:

```bash
node scripts/migrate-supabase-media-to-r2.mjs
```

يجب توفير متغيرات Supabase/R2 المطلوبة في بيئة التشغيل قبل تشغيل السكربت.

## مهم
لا تحذف مجلدي `videos` و`thumbnails` من Supabase Storage إلا بعد اختبار جميع الفيديوهات والصور القديمة من الموقع والتأكد أن قاعدة البيانات أصبحت تحتوي على مسارات `r2:` للوسائط المنقولة.
