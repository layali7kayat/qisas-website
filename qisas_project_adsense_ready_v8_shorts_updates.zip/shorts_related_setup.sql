-- تشغيل هذا الكود مرة واحدة في Supabase SQL Editor
-- يضيف الفيديو المرتبط بالـShort ويثبت تاريخ إضافة الفيديو داخل الوصف.

alter table public.videos
add column if not exists related_video_id uuid references public.videos(id) on delete set null;

create index if not exists videos_related_video_id_idx
on public.videos (related_video_id);

-- إضافة تاريخ الإضافة إلى أوصاف الفيديوهات الحالية التي لا تحتوي عليه.
-- التاريخ يعتمد على created_at الموجود أصلًا في قاعدة البيانات.
update public.videos
set description = trim(coalesce(description, '')) ||
  case when trim(coalesce(description, '')) = '' then '' else E'\n\n' end ||
  'تاريخ إضافة الفيديو: ' || to_char(created_at at time zone 'Asia/Muscat', 'YYYY-MM-DD')
where coalesce(description, '') not like '%تاريخ إضافة الفيديو:%';

-- ملاحظة: عند إضافة Short جديد من لوحة الإدارة، يتم حفظ related_video_id
-- فقط لفيديو منشور، وسيتم أيضًا وضع تاريخ الإضافة تلقائيًا داخل الوصف.
