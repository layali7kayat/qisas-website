import { createClient } from "jsr:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ success: false, error: "Method not allowed" }, 405);

  try {
    const MUSCAT_TZ = "Asia/Muscat";
function addedDateLabel(iso: string) {
  const d = new Date(iso);
  return new Intl.DateTimeFormat("en-CA", { timeZone: MUSCAT_TZ, year: "numeric", month: "2-digit", day: "2-digit" }).format(d);
}
function ensureAddedDate(description: string, iso: string) {
  const clean = String(description || "").trim();
  if (/تاريخ إضافة الفيديو\s*:/i.test(clean)) return clean;
  const dateLine = `تاريخ إضافة الفيديو: ${addedDateLabel(iso)}`;
  return clean ? `${clean}\n\n${dateLine}` : dateLine;
}

const form = await req.formData();
    const rawAction = String(form.get("action") || "").trim();
    const action = rawAction || (form.get("video_id") ? "set_featured" : "create");
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!supabaseUrl || !serviceRoleKey) {
      return json({ success: false, error: "Supabase environment variables are missing" }, 500);
    }

    const supabase = createClient(supabaseUrl, serviceRoleKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    // PUBLIC SHORT COMMENTS: these actions do not require the admin PIN.
    if (action === "list_comments") {
      const videoId = String(form.get("video_id") || "").trim();
      if (!videoId) return json({ success: false, error: "معرّف الفيديو مطلوب" }, 400);
      const { data, error } = await supabase
        .from("short_comments")
        .select("id,video_id,text,author_token,created_at")
        .eq("video_id", videoId)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return json({ success: true, comments: data || [] });
    }

    if (action === "add_comment") {
      const videoId = String(form.get("video_id") || "").trim();
      const text = String(form.get("text") || "").trim();
      const authorToken = String(form.get("author_token") || "").trim();
      if (!videoId || !text || !authorToken) return json({ success: false, error: "بيانات التعليق ناقصة" }, 400);
      if (text.length > 300 || authorToken.length < 20 || authorToken.length > 100) {
        return json({ success: false, error: "بيانات التعليق غير صالحة" }, 400);
      }
      const { data, error } = await supabase
        .from("short_comments")
        .insert({ video_id: videoId, text, author_token: authorToken })
        .select("id,video_id,text,author_token,created_at")
        .single();
      if (error) throw error;
      return json({ success: true, comment: data });
    }

    if (action === "delete_my_comment") {
      const id = String(form.get("id") || "").trim();
      const authorToken = String(form.get("author_token") || "").trim();
      if (!id || !authorToken) return json({ success: false, error: "بيانات الحذف ناقصة" }, 400);
      const { error } = await supabase.from("short_comments").delete().eq("id", id).eq("author_token", authorToken);
      if (error) throw error;
      return json({ success: true, message: "تم حذف تعليقك" });
    }

    // All remaining actions are admin actions and require the PIN.
    const pin = String(form.get("pin") || "");
    const adminPin = Deno.env.get("ADMIN_PIN") || "";
    if (!adminPin || pin !== adminPin) {
      return json({ success: false, error: "رمز الإدارة غير صحيح" }, 401);
    }

    if (action === "set_featured" || action === "save_featured" || action === "feature_video") {
      const videoId = String(form.get("video_id") || "").trim();
      if (!videoId) return json({ success: false, error: "معرّف الفيديو مطلوب" }, 400);
      const { error } = await supabase.from("site_settings").upsert({
        id: 1,
        featured_video_id: videoId,
        updated_at: new Date().toISOString(),
      });
      if (error) throw error;
      return json({ success: true, message: "تم تثبيت الفيديو" });
    }

    if (action === "clear_featured") {
      const { error } = await supabase.from("site_settings").upsert({
        id: 1,
        featured_video_id: null,
        updated_at: new Date().toISOString(),
      });
      if (error) throw error;
      return json({ success: true, message: "تم إلغاء الفيديو المثبت" });
    }

    // ADMIN COMMENT DELETE
    if (action === "delete_comment") {
      const id = String(form.get("id") || "").trim();
      if (!id) return json({ success: false, error: "معرّف التعليق مطلوب" }, 400);
      const { error } = await supabase.from("short_comments").delete().eq("id", id);
      if (error) throw error;
      return json({ success: true, message: "تم حذف التعليق" });
    }

    // DELETE: remove the database record first so a storage cleanup problem
    // cannot leave the video visible on the site.
    if (action === "delete") {
      const id = String(form.get("id") || "").trim();
      if (!id) return json({ success: false, error: "معرّف القصة مطلوب" }, 400);

      const { data: video, error: findError } = await supabase
        .from("videos")
        .select("id, video_path, thumbnail_path")
        .eq("id", id)
        .maybeSingle();

      if (findError) throw findError;
      if (!video) return json({ success: false, error: "القصة غير موجودة" }, 404);

      const { error: deleteError } = await supabase
        .from("videos")
        .delete()
        .eq("id", id);

      if (deleteError) throw deleteError;

      const cleanupErrors: string[] = [];

      if (video.video_path) {
        const { error } = await supabase.storage.from("videos").remove([video.video_path]);
        if (error) cleanupErrors.push(`video: ${error.message}`);
      }

      if (video.thumbnail_path) {
        const { error } = await supabase.storage.from("thumbnails").remove([video.thumbnail_path]);
        if (error) cleanupErrors.push(`thumbnail: ${error.message}`);
      }

      return json({
        success: true,
        message: "تم حذف القصة بنجاح",
        cleanupWarnings: cleanupErrors,
      });
    }

    const title = String(form.get("title") || "").trim();
    const description = String(form.get("description") || "").trim();
    const video = form.get("video");
    const thumbnail = form.get("thumbnail");
    const isShort = String(form.get("is_short") || "false") === "true";
    const requestedRelatedVideoId = String(form.get("related_video_id") || "").trim();
    let relatedVideoId: string | null = null;
    if (isShort && requestedRelatedVideoId) {
      const { data: relatedVideo, error: relatedError } = await supabase
        .from("videos")
        .select("id,status,is_short")
        .eq("id", requestedRelatedVideoId)
        .eq("status", "published")
        .eq("is_short", false)
        .maybeSingle();
      if (relatedError) throw relatedError;
      if (!relatedVideo) return json({ success: false, error: "فيديو القصة المرتبط يجب أن يكون فيديو منشورًا." }, 400);
      relatedVideoId = requestedRelatedVideoId;
    }

    if (!title) return json({ success: false, error: "عنوان الفيديو مطلوب" }, 400);

    // UPDATE
    if (action === "update") {
      const id = String(form.get("id") || "").trim();
      if (!id) return json({ success: false, error: "معرّف القصة مطلوب" }, 400);

      const { data: old, error: findError } = await supabase
        .from("videos")
        .select("*")
        .eq("id", id)
        .maybeSingle();

      if (findError) throw findError;
      if (!old) return json({ success: false, error: "القصة غير موجودة" }, 404);

      let videoPath = old.video_path;
      let thumbnailPath = old.thumbnail_path;
      let newVideoPath: string | null = null;
      let newThumbnailPath: string | null = null;

      if (video instanceof File && video.size > 0) {
        if (video.type !== "video/mp4") return json({ success: false, error: "الفيديو يجب أن يكون بصيغة MP4" }, 400);
        if (video.size > 50 * 1024 * 1024) return json({ success: false, error: "حجم الفيديو أكبر من 50MB" }, 400);

        const id2 = crypto.randomUUID();
        const safe = video.name.replace(/[^a-zA-Z0-9._-]/g, "-").replace(/-+/g, "-").slice(0, 80) || "video.mp4";
        newVideoPath = `${id2}-${safe}`;

        const { error } = await supabase.storage.from("videos").upload(newVideoPath, video, {
          contentType: "video/mp4",
          upsert: false,
        });
        if (error) throw error;
        videoPath = newVideoPath;
      }

      if (thumbnail instanceof File && thumbnail.size > 0) {
        if (!["image/jpeg", "image/png", "image/webp"].includes(thumbnail.type)) {
          return json({ success: false, error: "الصورة المصغرة يجب أن تكون JPG أو PNG أو WEBP" }, 400);
        }

        const id2 = crypto.randomUUID();
        const ext = thumbnail.type === "image/png" ? "png" : thumbnail.type === "image/webp" ? "webp" : "jpg";
        newThumbnailPath = `${id2}-thumbnail.${ext}`;

        const { error } = await supabase.storage.from("thumbnails").upload(newThumbnailPath, thumbnail, {
          contentType: thumbnail.type,
          upsert: false,
        });
        if (error) throw error;
        thumbnailPath = newThumbnailPath;
      }

      const { data, error: updateError } = await supabase
        .from("videos")
        .update({ title, description: ensureAddedDate(description, old.created_at), video_path: videoPath, thumbnail_path: thumbnailPath, is_short: isShort, related_video_id: isShort ? relatedVideoId : null })
        .eq("id", id)
        .select()
        .single();

      if (updateError) throw updateError;

      if (newVideoPath && old.video_path) await supabase.storage.from("videos").remove([old.video_path]);
      if (newThumbnailPath && old.thumbnail_path) await supabase.storage.from("thumbnails").remove([old.thumbnail_path]);

      return json({ success: true, message: "تم حفظ التعديلات", video: data });
    }

    // CREATE
    if (!(video instanceof File)) return json({ success: false, error: "لم يتم اختيار فيديو" }, 400);
    if (video.type !== "video/mp4") return json({ success: false, error: "الفيديو يجب أن يكون بصيغة MP4" }, 400);
    if (video.size > 50 * 1024 * 1024) return json({ success: false, error: "حجم الفيديو أكبر من 50MB" }, 400);

    const id = crypto.randomUUID();
    const safe = video.name.replace(/[^a-zA-Z0-9._-]/g, "-").replace(/-+/g, "-").slice(0, 80) || "video.mp4";
    const videoPath = `${id}-${safe}`;

    const { error: videoError } = await supabase.storage.from("videos").upload(videoPath, video, {
      contentType: "video/mp4",
      upsert: false,
    });
    if (videoError) throw videoError;

    let thumbnailPath: string | null = null;
    if (thumbnail instanceof File && thumbnail.size > 0) {
      if (!["image/jpeg", "image/png", "image/webp"].includes(thumbnail.type)) {
        await supabase.storage.from("videos").remove([videoPath]);
        return json({ success: false, error: "صورة الغلاف يجب أن تكون JPG أو PNG أو WEBP" }, 400);
      }

      const ext = thumbnail.type === "image/png" ? "png" : thumbnail.type === "image/webp" ? "webp" : "jpg";
      thumbnailPath = `${id}-thumbnail.${ext}`;
      const { error: thumbnailError } = await supabase.storage.from("thumbnails").upload(thumbnailPath, thumbnail, {
        contentType: thumbnail.type,
        upsert: false,
      });
      if (thumbnailError) {
        await supabase.storage.from("videos").remove([videoPath]);
        throw thumbnailError;
      }
    }

    const { data, error: dbError } = await supabase
      .from("videos")
      .insert({ title, description: ensureAddedDate(description, new Date().toISOString()), video_path: videoPath, thumbnail_path: thumbnailPath, is_short: isShort, related_video_id: isShort ? relatedVideoId : null, status: "published" })
      .select()
      .single();

    if (dbError) {
      await supabase.storage.from("videos").remove([videoPath]);
      if (thumbnailPath) await supabase.storage.from("thumbnails").remove([thumbnailPath]);
      throw dbError;
    }

    return json({ success: true, message: "تم نشر الفيديو بنجاح", video: data });
  } catch (error) {
    console.error(error);
    return json({
      success: false,
      error: error instanceof Error ? error.message : "حدث خطأ أثناء العملية",
    }, 500);
  }
});
