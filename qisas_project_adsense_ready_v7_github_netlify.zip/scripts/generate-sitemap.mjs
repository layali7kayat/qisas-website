import { writeFile } from 'node:fs/promises';

const SITE_URL = 'https://glittery-marzipan-fc84ea.netlify.app';
const SUPABASE_URL = 'https://ziflkciuftbgyxkzodqa.supabase.co';
const SUPABASE_KEY = process.env.SUPABASE_ANON_KEY || 'sb_publishable_l7DBXpvynUVO2LZEW9qfHA_KXECbRAh';

const staticPages = [
  ['/', 'weekly', '1.0'],
  ['/videos', 'weekly', '0.9'],
  ['/shorts', 'weekly', '0.8'],
  ['/channel-about.html', 'monthly', '0.7'],
  ['/about.html', 'monthly', '0.6'],
  ['/contact.html', 'monthly', '0.6'],
  ['/privacy.html', 'yearly', '0.4'],
  ['/cookies.html', 'yearly', '0.4'],
  ['/terms.html', 'yearly', '0.4'],
  ['/disclaimer.html', 'yearly', '0.4'],
];

function esc(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

async function getPublishedVideos() {
  const url = new URL(`${SUPABASE_URL}/rest/v1/videos`);
  url.searchParams.set('select', 'id,created_at,status,is_short');
  url.searchParams.set('status', 'eq.published');
  url.searchParams.set('order', 'created_at.desc');
  const response = await fetch(url, {
    headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` },
  });
  if (!response.ok) throw new Error(`Supabase request failed: ${response.status}`);
  return response.json();
}

const urls = [...staticPages.map(([path, freq, priority]) => ({
  loc: `${SITE_URL}${path}`,
  freq,
  priority,
}))];

try {
  const videos = await getPublishedVideos();
  for (const video of videos) {
    const path = video.is_short
      ? `/shorts-viewer.html?id=${encodeURIComponent(video.id)}`
      : `/watch.html?id=${encodeURIComponent(video.id)}`;
    urls.push({
      loc: `${SITE_URL}${path}`,
      freq: 'weekly',
      priority: video.is_short ? '0.7' : '0.8',
      lastmod: video.created_at ? new Date(video.created_at).toISOString() : undefined,
    });
  }
  console.log(`Sitemap: added ${videos.length} published videos/shorts.`);
} catch (error) {
  console.warn(`Sitemap warning: ${error.message}`);
  console.warn('Static pages will still be written.');
}

const xml = `<?xml version="1.0" encoding="UTF-8"?>\n` +
  `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n` +
  urls.map((u) => `  <url>\n    <loc>${esc(u.loc)}</loc>\n${u.lastmod ? `    <lastmod>${esc(u.lastmod)}</lastmod>\n` : ''}    <changefreq>${u.freq}</changefreq>\n    <priority>${u.priority}</priority>\n  </url>`).join('\n') +
  `\n</urlset>\n`;

await writeFile('sitemap.xml', xml, 'utf8');
console.log(`Sitemap: wrote ${urls.length} URLs.`);
