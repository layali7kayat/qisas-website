-- تشغيل هذا الملف مرة واحدة في Supabase SQL Editor
-- نظام تعليقات Shorts مع حذف تعليق صاحب التعليق وحذف الإدارة.

create table if not exists public.short_comments (
  id uuid primary key default gen_random_uuid(),
  video_id uuid not null references public.videos(id) on delete cascade,
  text text not null check (char_length(trim(text)) between 1 and 300),
  author_token text not null,
  created_at timestamptz not null default now()
);

create index if not exists short_comments_video_created_idx
on public.short_comments(video_id, created_at asc);

alter table public.short_comments enable row level security;

drop policy if exists "Anyone can read short comments" on public.short_comments;
create policy "Anyone can read short comments"
on public.short_comments
for select
to anon, authenticated
using (true);

drop policy if exists "Anyone can add short comments" on public.short_comments;
create policy "Anyone can add short comments"
on public.short_comments
for insert
to anon, authenticated
with check (
  char_length(trim(text)) between 1 and 300
  and char_length(author_token) between 20 and 100
);

-- الحذف العادي لا يتم مباشرة من المتصفح؛ يتم عبر هذه الدالة التي تتحقق من رمز صاحب التعليق.
create or replace function public.delete_my_short_comment(
  p_comment_id uuid,
  p_author_token text
)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  deleted_count integer;
begin
  delete from public.short_comments
  where id = p_comment_id
    and author_token = p_author_token;

  get diagnostics deleted_count = row_count;
  return deleted_count > 0;
end;
$$;

revoke all on function public.delete_my_short_comment(uuid, text) from public;
grant execute on function public.delete_my_short_comment(uuid, text) to anon, authenticated;
