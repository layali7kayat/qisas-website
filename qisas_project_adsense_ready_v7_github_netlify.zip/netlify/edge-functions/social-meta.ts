const SUPABASE_URL = "https://ziflkciuftbgyxkzodqa.supabase.co";
const SUPABASE_KEY = "sb_publishable_l7DBXpvynUVO2LZEW9qfHA_KXECbRAh";

function esc(value: unknown) {
  return String(value ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  }[c] || c));
}

function storagePublicUrl(bucket: string, path: string | null | undefined) {
  if (!path) return "";
  const encodedPath = String(path).split("/").map(encodeURIComponent).join("/");
  return `${SUPABASE_URL}/storage/v1/object/public/${bucket}/${encodedPath}`;
}

export default async function (request: Request, context: any) {
  const response = await context.next();

  try {
    const url = new URL(request.url);
    const id = url.searchParams.get("id");
    const titleParam = url.searchParams.get("title");

    let query = "";
    if (id) {
      query = `id=eq.${encodeURIComponent(id)}&status=eq.published`;
    } else if (titleParam) {
      query = `title=eq.${encodeURIComponent(titleParam)}&status=eq.published`;
    } else {
      return response;
    }

    const apiUrl =
      `${SUPABASE_URL}/rest/v1/videos?${query}` +
      `&select=title,description,thumbnail_path&limit=1`;

    const dbResponse = await fetch(apiUrl, {
      headers: {
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${SUPABASE_KEY}`,
      },
    });

    if (!dbResponse.ok) return response;

    const rows = await dbResponse.json();
    const video = Array.isArray(rows) ? rows[0] : null;
    if (!video) return response;

    const pageTitle = `${String(video.title || "مشاهدة القصة")} | قصص وحكايات الليل`;
    const description = String(video.description || "شاهد القصة كاملة على موقع قصص وحكايات الليل.");
    const image = storagePublicUrl("thumbnails", video.thumbnail_path);
    const canonical = url.href;

    const meta = `
<meta property="og:type" content="video.other">
<meta property="og:title" content="${esc(video.title || "مشاهدة القصة")}">
<meta property="og:description" content="${esc(description)}">
<meta property="og:url" content="${esc(canonical)}">
${image ? `<meta property="og:image" content="${esc(image)}">
<meta property="og:image:secure_url" content="${esc(image)}">
<meta property="og:image:type" content="image/jpeg">
<meta property="og:image:width" content="1280">
<meta property="og:image:height" content="720">` : ""}
<meta property="og:site_name" content="قصص وحكايات الليل">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="${esc(video.title || "مشاهدة القصة")}">
<meta name="twitter:description" content="${esc(description)}">
${image ? `<meta name="twitter:image" content="${esc(image)}">` : ""}
<link rel="canonical" href="${esc(canonical)}">`;

    const body = await response.text();
    const updated = body
      .replace(/<title>[\s\S]*?<\/title>/i, `<title>${esc(pageTitle)}</title>`)
      .replace(/<\/head>/i, `${meta}\n</head>`);

    const headers = new Headers(response.headers);
    headers.set("content-type", "text/html; charset=UTF-8");
    headers.delete("content-length");

    return new Response(updated, {
      status: response.status,
      statusText: response.statusText,
      headers,
    });
  } catch {
    return response;
  }
}
