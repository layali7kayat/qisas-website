# إعداد الموقع عبر GitHub + Netlify

هذا الإصدار يولد `sitemap.xml` تلقائيًا أثناء كل Deploy في Netlify، ويقرأ القصص المنشورة من Supabase.

مهم: رفع ZIP عبر Deploy manually لن يشغّل أمر Build. يجب ربط Netlify بمستودع GitHub وتشغيل Build command الموجود في `netlify.toml`.

Build command: `node scripts/generate-sitemap.mjs`
Publish directory: `.`

إذا أضيفت قصة جديدة إلى Supabase، يجب تشغيل Deploy جديد حتى يعاد بناء Sitemap. يمكن لاحقًا إضافة Netlify Build Hook/Webhook لتشغيل Deploy تلقائيًا عند نشر قصة جديدة.
