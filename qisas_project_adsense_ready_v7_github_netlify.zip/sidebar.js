function openSidebar(){document.getElementById('sideDrawer')?.classList.add('open');document.getElementById('drawerOverlay')?.classList.add('open');document.body.classList.add('drawer-open')}
function closeSidebar(){document.getElementById('sideDrawer')?.classList.remove('open');document.getElementById('drawerOverlay')?.classList.remove('open');document.body.classList.remove('drawer-open')}
