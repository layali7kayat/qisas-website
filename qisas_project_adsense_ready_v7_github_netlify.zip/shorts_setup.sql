-- تشغيل هذا الكود مرة واحدة في Supabase SQL Editor
-- يضيف نوع النشر للفيديوهات الحالية والجديدة.

alter table public.videos
add column if not exists is_short boolean not null default false;

update public.videos
set is_short = false
where is_short is null;

create index if not exists videos_is_short_idx
on public.videos (is_short, created_at desc);
