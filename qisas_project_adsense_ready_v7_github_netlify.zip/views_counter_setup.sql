-- تشغيل هذا الملف مرة واحدة في Supabase SQL Editor
-- عداد المشاهدات الحقيقي للموقع

create or replace function public.increment_video_views(p_video_id uuid)
returns bigint
language plpgsql
security definer
set search_path = public
as $$
declare
  new_views bigint;
begin
  update public.videos
  set views = coalesce(views, 0) + 1
  where id = p_video_id
    and status = 'published'
  returning views into new_views;

  return coalesce(new_views, 0);
end;
$$;

revoke all on function public.increment_video_views(uuid) from public;
grant execute on function public.increment_video_views(uuid) to anon, authenticated;
