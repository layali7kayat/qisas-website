-- شغّل هذا الملف مرة واحدة في Supabase SQL Editor
create table if not exists public.site_settings (
  id integer primary key check (id = 1),
  featured_video_id uuid references public.videos(id) on delete set null,
  updated_at timestamptz not null default now()
);

alter table public.site_settings enable row level security;

drop policy if exists "Anyone can view site settings" on public.site_settings;
create policy "Anyone can view site settings"
on public.site_settings
for select
to anon, authenticated
using (true);

insert into public.site_settings (id, featured_video_id)
values (1, null)
on conflict (id) do nothing;
